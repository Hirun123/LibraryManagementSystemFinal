/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagementsystem.Common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author HP
 */
public class DBConnection {
    
        
    private Connection con;
    
    private final String URI  = "jdbc:mysql://localhost/library";
    private final String USER  = "root";
    private final String PASS  = "123456";

    public Connection getCon() {
        return con;
    }

//    public void setCon(Connection con) {
//        this.con = con;
//    }

    
    
    public void Open()
    {
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            this.con = DriverManager.getConnection(URI,USER,PASS);
        } catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public void Close()
    {        
        try {
            this.con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
